
class song{
    constructor(id,name){
        this.id = id;
        this.name = name;
    }
}

class PlayList{
    constructor(name,saveSonglist){
        this.name = name;
        this.saveSonglist = saveSonglist;
    }
}

let allSongList = [
    new song(1,"Cheap Thrills"),
    new song(2,"Shape of You"),
    new song(3,"Despacito" ),
    new song(4,"Cuptown Funk"),
    new song(5,"All Too Well"),
    new song(6,"End Of The Road") ,
    new song(7,"Butter"),
    new song(8,"Cold Heart"),
    new song(9,"Long"),
    new song(10,"Shape of You"),
    new song(11,"Shape of You")
];

var saveSongs = new Array();

function isLocalStorageKeyExists(key) {
    return localStorage.getItem(key) !== null;
}

function saveThePlayListtoLoalStorage(plylst){
    let PlayLists = null;
    if(isLocalStorageKeyExists("PlayLists")){
        debugger;
        console.log("Has Element");
        debugger;
        plyListFoundFlag = false;
        let playlistJson = localStorage.getItem('PlayLists');
        PlayLists = JSON.parse(playlistJson);

        for(playlist in PlayLists){
            if(PlayLists[playlist].name == plylst.name){
                PlayLists[playlist] = plylst;
                plyListFoundFlag = true;
            }
        }
        if(plyListFoundFlag==false)
            PlayLists.push(plylst);
    }
    else
    {
        PlayLists  = new Array();
        PlayLists.push(plylst);
    }
    const jsonData_plyLst = JSON.stringify(PlayLists);
    localStorage.setItem('PlayLists', jsonData_plyLst);
    saveSongs = new Array();
}

function clearAllSaveSong(){
    saveSongs = new Array();
    $("#listOfSelectedSongs").empty();
    $("#PlayListName").val("");
    $("#PlayListName").prop("disabled", false);


}
function CreateDefaultPlayListCard(rowDiv){

    let columnsDic = document.createElement("div");
    columnsDic.className="col-md-2 p-2 m-2";

    let CardDiv = document.createElement("div");
    CardDiv.className="card";
    CardDiv.setAttribute("style","border:none");

    let buttonObj = document.createElement("button");
    buttonObj.id = "BtnAddModifyPlayList";
    buttonObj.setAttribute("type","button");
    buttonObj.className = "navbar-brand text-white";
    buttonObj.setAttribute("style","border:none;background:none");
    buttonObj.setAttribute("target","right-side");
    buttonObj.setAttribute("data-bs-toggle","modal");
    buttonObj.setAttribute("data-bs-target","#AddModifyPlayList");

    let imgObj = document.createElement("img");
    imgObj.className="card-img-top";
    imgObj.setAttribute("src","Resources/image/AddplayListicon.png");
    imgObj.setAttribute("alt","Card image cap");
    buttonObj.append(imgObj);
    CardDiv.append(buttonObj);
    columnsDic.append(CardDiv);
    rowDiv.append(columnsDic);
}

function CreatePlayListCard(plyLstName,rowDiv){

    let columnsDic = document.createElement("div");
    columnsDic.className="col-md-2 p-2 m-2";

    let CardDiv = document.createElement("div");
    CardDiv.className="card";
    CardDiv.setAttribute("style","border:none");

    let buttonObj = document.createElement("button");
    buttonObj.id = "BtnAddModifyPlayList"+plyLstName;
    buttonObj.setAttribute("type","button");
    buttonObj.className = "navbar-brand text-white";
    buttonObj.setAttribute("style","border:none;background:none");
    buttonObj.setAttribute("target","right-side");
    buttonObj.setAttribute("data-bs-toggle","modal");
    buttonObj.setAttribute("data-bs-target","#AddModifyPlayList");
    buttonObj.addEventListener("click",function(){
        setTheplayListDetails(plyLstName);
    });


    let imgObj = document.createElement("img");
    imgObj.className="card-img-top";
    imgObj.setAttribute("src","Resources/image/flam.jpg");
    imgObj.setAttribute("alt","Card image cap");
    buttonObj.append(imgObj);
    CardDiv.append(buttonObj);

    let cardBody = document.createElement("div");
    cardBody.className="card-body";

    let hobj =  document.createElement("h5");
    hobj.class="card-title";
    hobj.innerHTML=plyLstName;
    cardBody.append(hobj);
    CardDiv.append(cardBody);
    columnsDic.append(CardDiv);
    rowDiv.append(columnsDic);
}


function ConstructAndDisplayCard(storedJsonString)
{
    debugger;
    let count = 1;
    let outDiv = document.createElement("div");
        outDiv.className = "container mt-3";
    let rowDiv = document.createElement("div");
        rowDiv.className="row";
    let columnsDic;

    CreateDefaultPlayListCard(rowDiv);
    storedJsonString = JSON.parse(storedJsonString);
    console.log("storedJsonString : "+storedJsonString);
    //Iterating through the object to create all playlist cards
    showAllPlatListbody  = document.getElementById("showAllPlatListbody");
    count++;
    for(i in storedJsonString){

        if(count==1){
            outDiv = document.createElement("div");
            outDiv.className = "container mt-3";

            rowDiv = document.createElement("div");
            rowDiv.className="row";
        }
        else if ((count==5) || (i==storedJsonString.length-1)){
            outDiv.append(rowDiv);
            count = 0;
        }

        CreatePlayListCard(storedJsonString[i].name,rowDiv);
        count++;
    }
    if(storedJsonString==null)
        outDiv.append(rowDiv);
    showAllPlatListbody.append(outDiv);
}

function DisplayAllplayList(){
    let storedJsonString = localStorage.getItem('PlayLists');
    if (storedJsonString !== null) {
        // Parse the JSON string back to an object
        let storedObject = JSON.parse(storedJsonString);
        console.log(storedObject);
    }
    ConstructAndDisplayCard(storedJsonString);
}

function getCurrentPLayist(plyLstName,storedJsonString){
    plsyListobjs = JSON.parse(storedJsonString);
    currentPLayList = new PlayList();
    for(playList of plsyListobjs){
        if(playList.name==plyLstName){
           return playList;
        }
    }
    return null;
}

function setTheplayListDetails(plyLstName){

    //Setting the playList Name and disabling the field
    $("#PlayListName").val(plyLstName);
    $("#PlayListName").prop("disabled", true);

    let storedJsonString = localStorage.getItem('PlayLists');
    if (storedJsonString !== null){
        currentPLayList = getCurrentPLayist(plyLstName,storedJsonString);

        //Setting the save
        //debugger;
        for(ss of currentPLayList.saveSonglist){
            AddCurrentSongtoTheList(ss)
        }
        //Calling the below to display all available playList which were not selected
        //before
        showPlayList("");
    }
}

function PlaylistFormSubmit(){
    event.preventDefault();
    let SerachedString = $("#searchString").val();
    showPlayList(SerachedString);
}

function SavePlayList(){
    event.preventDefault();
    playListName  = $("#PlayListName").val();
    plylst = new PlayList(playListName,saveSongs);
    saveThePlayListtoLoalStorage(plylst);

    alert("PlayList Saved successfully");
    //TO clear every thing
    clearAllSaveSong();

    //Set the available div
    showPlayList();

}

function RemoveFromSelectedItem(ss,obj){

    saveSongs = saveSongs.filter(song => song.id!==ss.id);
    obj.parentElement.remove();
    PlaylistFormSubmit();
}

function appendToSelectedList(ss){

    let listOfSelectedSongs = document.getElementById("listOfSelectedSongs");
    let myDiv = document.createElement('div');
    myDiv.id = ss.id;
    myDiv.className="p-1"
    myDiv.innerHTML = ss.name;
    let AddButton  = document.createElement("button");
    AddButton.setAttribute("style","border:none;background:none");
    AddButton.addEventListener("click",function(){
        RemoveFromSelectedItem(ss,this)
    });

    let Addicon = document.createElement("i");
    Addicon.className="fa fa-trash";
    Addicon.setAttribute("aria-hidden", "true");
    Addicon.setAttribute("target","right-side")
    AddButton.append(Addicon);
    myDiv.append(AddButton);
    listOfSelectedSongs.append(myDiv);
}

function AddCurrentSongtoTheList(ss,obj) {
   // debugger;
    saveSongs.push(ss);
    appendToSelectedList(ss);
}

function isAlreadyCheaked(ss){
    for(saveSong of saveSongs){
        if(saveSong.id == ss.id)
            return true;
    }
    return false;
}


function showPlayList(str){
    //Empty the current List
    document.getElementById("searchedSong").innerHTML="";
    let mainDivElement = document.createElement('div');
    for(let ss of allSongList){
        if((!isAlreadyCheaked(ss)) && (str==null || str==undefined || str=="" || ss.name.toLowerCase().includes(str.toLowerCase())))  {
            let myDiv = document.createElement('div');
            myDiv.id = ss.id;
            myDiv.className="p-1"
            myDiv.innerHTML = ss.name;

            let AddButton  = document.createElement("button");
            AddButton.setAttribute("style","border:none;background:none");
            AddButton.addEventListener("click",function(){
                AddCurrentSongtoTheList(ss,this);
                this.parentNode.remove();
            });

            let Addicon = document.createElement("i");
            Addicon.className="fa fa-plus";
            Addicon.setAttribute("aria-hidden", "true");
            Addicon.setAttribute("target","right-side")
            AddButton.append(Addicon);

            myDiv.append(AddButton);
            mainDivElement.append(myDiv);
        }
    }
    document.getElementById("searchedSong").append(mainDivElement);
}

$(document).ready(function(){
    console.log("java Script..");
    $("#includedContent").load("/AddModPlayList.html");
    $("#navBarDiv").load("/navBar.html");

    $("#BtnAddModifyPlayList").click(function(){
        showPlayList("");
    });

    //Setting showListofSongs page as default page
    $("#rightSideIframe").attr("src","showListofSongs.html");

});